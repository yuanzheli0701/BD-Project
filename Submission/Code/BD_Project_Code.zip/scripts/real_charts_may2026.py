# Real May 2026 music charts compiled from Wikipedia, Billboard, Oricon, ARIA, etc.
# Each entry: (song_name, artist_name)

REAL_CHARTS = {
  "us": [
    [
      "Drop Dead",
      "Olivia Rodrigo"
    ],
    [
      "Choosin' Texas",
      "Ella Langley"
    ],
    [
      "I Just Might",
      "Bruno Mars"
    ],
    [
      "Aperture",
      "Harry Styles"
    ],
    [
      "The Fate of Ophelia",
      "Taylor Swift"
    ],
    [
      "Janice STFU",
      "Drake"
    ],
    [
      "All I Want for Christmas Is You",
      "Mariah Carey"
    ],
    [
      "Die with a Smile",
      "Lady Gaga & Bruno Mars"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Cruel Summer",
      "Taylor Swift"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Someone You Loved",
      "Lewis Capaldi"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Save Your Tears",
      "The Weeknd"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Stay",
      "The Kid LAROI & Justin Bieber"
    ],
    [
      "Kill Bill",
      "SZA"
    ],
    [
      "About Damn Time",
      "Lizzo"
    ],
    [
      "First Class",
      "Jack Harlow"
    ],
    [
      "Industry Baby",
      "Lil Nas X"
    ],
    [
      "Montero",
      "Lil Nas X"
    ],
    [
      "Kiss Me More",
      "Doja Cat"
    ],
    [
      "Peaches",
      "Justin Bieber"
    ],
    [
      "Watermelon Sugar",
      "Harry Styles"
    ]
  ],
  "gb": [
    [
      "Rein Me In",
      "Sam Fender & Olivia Dean"
    ],
    [
      "Choosin' Texas",
      "Ella Langley"
    ],
    [
      "Die with a Smile",
      "Lady Gaga & Bruno Mars"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Someone You Loved",
      "Lewis Capaldi"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Shivers",
      "Ed Sheeran"
    ],
    [
      "Easy On Me",
      "Adele"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Drivers License",
      "Olivia Rodrigo"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Made You Look",
      "Meghan Trainor"
    ],
    [
      "Running Up That Hill",
      "Kate Bush"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "Houdini",
      "Dua Lipa"
    ],
    [
      "Greedy",
      "Tate McRae"
    ],
    [
      "Lovin On Me",
      "Jack Harlow"
    ],
    [
      "Paint The Town Red",
      "Doja Cat"
    ],
    [
      "Strangers",
      "Kenya Grace"
    ],
    [
      "Escapism",
      "RAYE"
    ],
    [
      "Golden Hour",
      "JVKE"
    ],
    [
      "My Love Mine All Mine",
      "Mitski"
    ]
  ],
  "jp": [
    [
      "Pulse",
      "INI"
    ],
    [
      "Bang!!",
      "Snow Man"
    ],
    [
      "Matane",
      "Domoto"
    ],
    [
      "Blue Noise",
      "Ryosuke Yamada"
    ],
    [
      "Star Wish",
      "Starglow"
    ],
    [
      "Cliffhanger",
      "Hinatazaka46"
    ],
    [
      "Spaghetti",
      "Le Sserafim"
    ],
    [
      "Tokyo Junction",
      "Show-Wa"
    ],
    [
      "Suki Nanka ja... Nyai!",
      "Fav Me"
    ],
    [
      "&Joy",
      "Kis-My-Ft2"
    ],
    [
      "Idol",
      "YOASOBI"
    ],
    [
      "KICK BACK",
      "Kenshi Yonezu"
    ],
    [
      "Habit",
      "SEKAI NO OWARI"
    ],
    [
      "Subtitle",
      "Official Hige Dandism"
    ],
    [
      "Shinjidai",
      "Ado"
    ],
    [
      "Mixed Nuts",
      "Official Hige Dandism"
    ],
    [
      "W/X/Y",
      "Tani Yuuki"
    ],
    [
      "Dai Zero Kan",
      "10-FEET"
    ],
    [
      "Kigeki",
      "Gen Hoshino"
    ],
    [
      "Chu Tayousei",
      "Ano"
    ],
    [
      "Suzume",
      "RADWIMPS feat. Toaka"
    ],
    [
      "Kaiju no Hanauta",
      "Vaundy"
    ],
    [
      "LADY",
      "Kenshi Yonezu"
    ],
    [
      "Work",
      "Millennium Parade & Ringo Sheena"
    ],
    [
      "Bling-Bang-Bang-Born",
      "Creepy Nuts"
    ],
    [
      "Nidone",
      "Creepy Nuts"
    ],
    [
      "Show",
      "Ado"
    ],
    [
      "Specialz",
      "King Gnu"
    ],
    [
      "Ao no Sumika",
      "Tatsuya Kitani"
    ],
    [
      "Where Our Blue Is",
      "Tatsuya Kitani"
    ]
  ],
  "de": [
    [
      "The Great Divide",
      "Noah Kahan"
    ],
    [
      "Hit Me Hard And Soft",
      "Billie Eilish"
    ],
    [
      "Alpha DNA",
      "Felix Blume"
    ],
    [
      "Komet",
      "Udo Lindenberg & Apache 207"
    ],
    [
      "Wildberry Lillet",
      "Nina Chuba"
    ],
    [
      "Zukunft Pink",
      "Peter Fox feat. Inez"
    ],
    [
      "Sie weiss",
      "AYLIVA feat. Mero"
    ],
    [
      "Friesenjung",
      "Ski Aggu, Joost & Otto Waalkes"
    ],
    [
      "M?dchen auf dem Pferd",
      "Luca-Dante Spadafora"
    ],
    [
      "Bamba",
      "Luciano feat. Aitch & BIA"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "I'm Good (Blue)",
      "David Guetta & Bebe Rexha"
    ],
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Easy On Me",
      "Adele"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "Greedy",
      "Tate McRae"
    ],
    [
      "Strangers",
      "Kenya Grace"
    ],
    [
      "Paint The Town Red",
      "Doja Cat"
    ],
    [
      "Houdini",
      "Dua Lipa"
    ]
  ],
  "fr": [
    [
      "Sexy Nana",
      "Aya Nakamura"
    ],
    [
      "melodrama",
      "Disiz"
    ],
    [
      "Derniere Danse",
      "Indila"
    ],
    [
      "Bande Organisee",
      "13Organise"
    ],
    [
      "Petit Genie",
      "Jungeli feat. Abou Debeing"
    ],
    [
      "Tourner Dans Le Vide",
      "Indila"
    ],
    [
      "Djadja",
      "Aya Nakamura"
    ],
    [
      "Pookie",
      "Aya Nakamura"
    ],
    [
      "Copines",
      "Aya Nakamura"
    ],
    [
      "Flamme",
      "Juliette Armanet"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Shivers",
      "Ed Sheeran"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "STAY",
      "The Kid LAROI & Justin Bieber"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Kill Bill",
      "SZA"
    ],
    [
      "I'm Good",
      "David Guetta & Bebe Rexha"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "Paint The Town Red",
      "Doja Cat"
    ],
    [
      "Houdini",
      "Dua Lipa"
    ]
  ],
  "au": [
    [
      "Rein Me In",
      "Sam Fender & Olivia Dean"
    ],
    [
      "Man I Need",
      "Olivia Dean"
    ],
    [
      "Choosin' Texas",
      "Ella Langley"
    ],
    [
      "Stay",
      "The Kid LAROI & Justin Bieber"
    ],
    [
      "Dance Monkey",
      "Tones and I"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Riptide",
      "Vance Joy"
    ],
    [
      "Youngblood",
      "5 Seconds of Summer"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Drivers License",
      "Olivia Rodrigo"
    ],
    [
      "Shivers",
      "Ed Sheeran"
    ],
    [
      "Save Your Tears",
      "The Weeknd"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "Greedy",
      "Tate McRae"
    ],
    [
      "Paint The Town Red",
      "Doja Cat"
    ],
    [
      "Strangers",
      "Kenya Grace"
    ],
    [
      "Golden Hour",
      "JVKE"
    ],
    [
      "Lovin On Me",
      "Jack Harlow"
    ],
    [
      "Kill Bill",
      "SZA"
    ]
  ],
  "in": [
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Kesariya",
      "Arijit Singh"
    ],
    [
      "Pasoori",
      "Ali Sethi & Shae Gill"
    ],
    [
      "Maan Meri Jaan",
      "King"
    ],
    [
      "Srivalli",
      "Sid Sriram"
    ],
    [
      "Raataan Lambiyan",
      "Jubin Nautiyal & Asees Kaur"
    ],
    [
      "Ranjha",
      "B Praak & Jasleen Royal"
    ],
    [
      "Bhool Bhulaiyaa 2 Title Track",
      "Tanishk Bagchi"
    ],
    [
      "Kya Baat Haii 2.0",
      "Harrdy Sandhu"
    ],
    [
      "Naatu Naatu",
      "Rahul Sipligunj & Kaala Bhairava"
    ],
    [
      "Chaand Baaliyan",
      "Aditya A"
    ],
    [
      "Jhoome Jo Pathaan",
      "Arijit Singh"
    ],
    [
      "Apna Bana Le",
      "Arijit Singh"
    ],
    [
      "Tum Hi Ho",
      "Arijit Singh"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Stay",
      "The Kid LAROI & Justin Bieber"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "Kill Bill",
      "SZA"
    ],
    [
      "Save Your Tears",
      "The Weeknd"
    ]
  ],
  "br": [
    [
      "Le Gusta Que La Vean",
      "MC Kevin o Chris"
    ],
    [
      "Tubarao Te Amo",
      "DJ LK da Escocia"
    ],
    [
      "Pipoco",
      "Ana Castela & Melody"
    ],
    [
      "Bandido",
      "Z? Felipe & MC Mari"
    ],
    [
      "Envolver",
      "Anitta"
    ],
    [
      "Boys Dont Cry",
      "Anitta"
    ],
    [
      "Nosso Quadro",
      "AgroPlay & Ana Castela"
    ],
    [
      "Erro Gostoso",
      "Simone Mendes"
    ],
    [
      "Taj Mahal",
      "Jorge Ben Jor"
    ],
    [
      "Garota de Ipanema",
      "Tom Jobim"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Shivers",
      "Ed Sheeran"
    ],
    [
      "Stay",
      "The Kid LAROI & Justin Bieber"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Kill Bill",
      "SZA"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "I'm Good",
      "David Guetta & Bebe Rexha"
    ],
    [
      "Paint The Town Red",
      "Doja Cat"
    ],
    [
      "Greedy",
      "Tate McRae"
    ]
  ],
  "kr": [
    [
      "Super Shy",
      "NewJeans"
    ],
    [
      "ETA",
      "NewJeans"
    ],
    [
      "OMG",
      "NewJeans"
    ],
    [
      "Ditto",
      "NewJeans"
    ],
    [
      "Like Crazy",
      "Jimin"
    ],
    [
      "Seven",
      "Jungkook feat. Latto"
    ],
    [
      "3D",
      "Jungkook"
    ],
    [
      "Flower",
      "Jisoo"
    ],
    [
      "Queencard",
      "(G)I-DLE"
    ],
    [
      "Cupid",
      "FIFTY FIFTY"
    ],
    [
      "Baddie",
      "IVE"
    ],
    [
      "I AM",
      "IVE"
    ],
    [
      "Unforgiven",
      "LE SSERAFIM"
    ],
    [
      "Spicy",
      "aespa"
    ],
    [
      "Drama",
      "aespa"
    ],
    [
      "Super",
      "SEVENTEEN"
    ],
    [
      "Fighting",
      "BSS feat. Lee Young Ji"
    ],
    [
      "S-Class",
      "Stray Kids"
    ],
    [
      "Shut Down",
      "BLACKPINK"
    ],
    [
      "Pink Venom",
      "BLACKPINK"
    ],
    [
      "Butter",
      "BTS"
    ],
    [
      "Dynamite",
      "BTS"
    ],
    [
      "Permission to Dance",
      "BTS"
    ],
    [
      "LALISA",
      "Lisa"
    ],
    [
      "MONEY",
      "Lisa"
    ],
    [
      "That That",
      "PSY feat. Suga"
    ],
    [
      "Hype Boy",
      "NewJeans"
    ],
    [
      "Attention",
      "NewJeans"
    ],
    [
      "Love Lee",
      "AKMU"
    ],
    [
      "Fast Forward",
      "Jeon Somi"
    ]
  ],
  "ru": [
    [
      "Komarovo",
      "INSTASAMKA"
    ],
    [
      "Za Dengi Da",
      "INSTASAMKA"
    ],
    [
      "Vyhodnoy",
      "Miyagi & Andy Panda"
    ],
    [
      "Minor",
      "Miyagi & Andy Panda"
    ],
    [
      "Patron",
      "Miyagi & Andy Panda"
    ],
    [
      "Yamakasi",
      "Miyagi & Andy Panda"
    ],
    [
      "Captain",
      "Miyagi"
    ],
    [
      "Dream Garden",
      "Miyagi & ????????"
    ],
    [
      "Cadillac",
      "Morgenshtern & Eldzhey"
    ],
    [
      "Poezd",
      "LSP"
    ],
    [
      "Cristal & MOET",
      "Morgenshtern"
    ],
    [
      "Pablo",
      "Morgenshtern"
    ],
    [
      "Blinding Lights",
      "The Weeknd"
    ],
    [
      "As It Was",
      "Harry Styles"
    ],
    [
      "Flowers",
      "Miley Cyrus"
    ],
    [
      "Shape of You",
      "Ed Sheeran"
    ],
    [
      "Anti-Hero",
      "Taylor Swift"
    ],
    [
      "Bad Guy",
      "Billie Eilish"
    ],
    [
      "Unholy",
      "Sam Smith"
    ],
    [
      "Levitating",
      "Dua Lipa"
    ],
    [
      "Stay",
      "The Kid LAROI & Justin Bieber"
    ],
    [
      "Cold Heart",
      "Elton John & Dua Lipa"
    ],
    [
      "Heat Waves",
      "Glass Animals"
    ],
    [
      "Calm Down",
      "Rema"
    ],
    [
      "Good 4 U",
      "Olivia Rodrigo"
    ],
    [
      "Vampire",
      "Olivia Rodrigo"
    ],
    [
      "Water",
      "Tyla"
    ],
    [
      "Kill Bill",
      "SZA"
    ],
    [
      "Paint The Town Red",
      "Doja Cat"
    ],
    [
      "Houdini",
      "Dua Lipa"
    ]
  ]
}